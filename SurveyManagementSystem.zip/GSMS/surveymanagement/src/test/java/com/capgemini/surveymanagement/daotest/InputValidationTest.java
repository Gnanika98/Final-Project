package com.capgemini.surveymanagement.daotest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveymanagement.factory.Factory;
import com.capgemini.surveymanagement.validations.InputValidation;

class InputValidationTest {
	@Test
	@DisplayName("usernamevalidation")
	public void testName() {
		InputValidation nameValidation = Factory.getInputValidationInstance();
		assertEquals(true, nameValidation.usernameValidation("Admin"));
	}

	@Test
	@DisplayName("mailvalidation")
	public void testEmailValidation() {
		InputValidation mailValidation = Factory.getInputValidationInstance();
		assertEquals(true, mailValidation.mailIdValidation("Surveyor1@gmail.com"));
	}

	@Test
	@DisplayName("surveyTitleValidation")
	public void testSurveyTitleValidation() {
		InputValidation surveyTitleValidation = Factory.getInputValidationInstance();
		assertEquals(true, surveyTitleValidation.titleValidation("Phonepe"));
	}

	@Test
	@DisplayName("choicevalidation")
	public void testChoiceValidation() {
		InputValidation choiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, choiceValidation.choiceValidation("1"));
	}

	@Test
	@DisplayName("idValidation")
	public void testIdValidation() {
		InputValidation idValidation = Factory.getInputValidationInstance();
		assertEquals(true, idValidation.idValidation("1"));
	}

	@Test
	@DisplayName("passwordValidation")
	public void testPasswordValidation() {
		InputValidation passwordValidation = Factory.getInputValidationInstance();
		assertEquals(true, passwordValidation.passwordValidation("Admin@1"));
	}

	@Test
	@DisplayName("contactValidation")
	public void testOptionValidation() {
		InputValidation optionValidation = Factory.getInputValidationInstance();
		assertEquals(true, optionValidation.contactValidation("4875125849"));
	}

}
