package com.capgemini.surveymanagement.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveymanagement.bean.RespondentBean;
import com.capgemini.surveymanagement.bean.RespondentDetails;
import com.capgemini.surveymanagement.bean.SurveyDetails;
import com.capgemini.surveymanagement.exception.RespondentIdNotFoundException;
import com.capgemini.surveymanagement.exception.RespondentNotFoundException;
import com.capgemini.surveymanagement.exception.SurveyNotFoundException;
import com.capgemini.surveymanagement.factory.Factory;
import com.capgemini.surveymanagement.service.Service;

public class RespondentController {
	static Service service = Factory.getServiceInstance();
	static RespondentBean respondent = Factory.getRespondentBeanInstance();
	static SurveyDetails surveyDetails = Factory.getSurveyDetailsInstance();
	static List<SurveyDetails> surveyDetailsList = new ArrayList<SurveyDetails>();
	static List<RespondentDetails> respondentDetailsList = new ArrayList<RespondentDetails>();

	static List<RespondentBean> respondentList = new ArrayList<RespondentBean>();
	static final Logger logger = Logger.getLogger(RespondentController.class);
	static Scanner sc = new Scanner(System.in);
	static RespondentDetails respondentDetails = Factory.getRespondentDetailsInstance();
	static int count = 0;

	private RespondentController() {

	}

	// This method is used by the respondent to login into his account.
	public static void respondentLogin() {
		Properties property = new Properties();
		try {
			property.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		String respondentUsername = property.getProperty("respondentUsername");
		String respondentPassword = property.getProperty("respondentPassword");
		logger.info("respondentUsername: " + respondentUsername);
		logger.info("respondentPassword: " + respondentPassword);
		try {
			logger.info("Enter Username");
			respondentUsername = sc.next();
			while (!service.usernameValidation(respondentUsername)) {
				logger.info("Enter valid respondentusername");
				respondentUsername = sc.next();
			}
			logger.info("Enter Password");
			respondentPassword = sc.next();
			while (!service.passwordValidation(respondentPassword)) {
				logger.info("Enter valid Credentials");
				respondentLogin();
			}
				boolean value = service.respondentLoginService(respondentUsername, respondentPassword);
				if (value) {
					logger.info("Respondent Login Successful");
					afterRespondentLogin();
				} else {
					throw new RespondentNotFoundException();
				}
			
		} catch (RespondentNotFoundException e) {
			logger.error(e.getMessage());
		}
	}

	// After respondent Login we use this method to perform the respondent
	// Operations.

	public static void afterRespondentLogin() {
		K: do {
			logger.info("***WELCOME RESPONDENT***");
			logger.info("1.Respond to Survey");
			logger.info("2.View Response");
			logger.info("3.View all responded surveyes");
			logger.info("4.Exit");
			String option = sc.next();
			while (!service.respondentChoiceValidation(option)) {
				logger.info("please enter valid choice: Accepts only [1-4] ");
				option = sc.next();
			}
			int select = Integer.parseInt(option);

			switch (select) {

			case 1:
				logger.info("Respond to survey");
				respondToSurvey();
				break;
			case 2:
				logger.info("View Response");
				viewResponse();
				break;
			case 3:
				logger.info("view All Responded Surveyes");
				viewAllRespondedSurveyes();
				break;
			case 4:
				AdminController.afterAdminLogin();
				System.exit(0);
				sc.close();
				break K;
			default:
				logger.info("Enter valid choice");
				break;
			}
		} while (true);
	}

	// This method is used to respond to a survey.

	public static void respondToSurvey() {
		logger.info("Enter surveyId to respond:which must be between [0-9] and min 1 and max 10");
		String surveyId = sc.next();
		while (!service.idValidation(surveyId)) {
			logger.info("Enter valid SurveyId: which must be between [0-9] and min 1 and max 10");
			surveyId = sc.next();
			logger.info(surveyId);
		}
		SurveyDetails surveyDetails = Factory.getServiceInstance().getSurveyService(surveyId);
		logger.info("1. " + surveyDetails.getQuestion1());
		logger.info("Select your option");
		logger.info("1. " + surveyDetails.getQ1Option1());
		logger.info("2. " + surveyDetails.getQ1Option2());
		logger.info("3. " + surveyDetails.getQ1Option3());
		logger.info("4. " + surveyDetails.getQ1Option4());
		logger.info("submit your option:from [1-4]");
		String answer1 = sc.next();
		while (!service.surveyorChoiceValidation(answer1)) {
			logger.info("Enter a valid option:from [1-4]");
			answer1 = sc.next();
		}
		int ans1 = Integer.parseInt(answer1);
		if (ans1 == 1)
			respondentDetails.setAnswer1(surveyDetails.getQ1Option1());
		if (ans1 == 2)
			respondentDetails.setAnswer1(surveyDetails.getQ1Option2());
		if (ans1 == 3)
			respondentDetails.setAnswer1(surveyDetails.getQ1Option3());
		if (ans1 == 4)
			respondentDetails.setAnswer1(surveyDetails.getQ1Option4());

		logger.info("2. " + surveyDetails.getQuestion2());
		logger.info("Select your option");
		logger.info("1. " + surveyDetails.getQ2Option1());
		logger.info("2. " + surveyDetails.getQ2Option2());
		logger.info("3. " + surveyDetails.getQ2Option3());
		logger.info("4. " + surveyDetails.getQ2Option4());
		logger.info("submit your option from [1-4]");
		String answer2 = sc.next();
		while (!service.surveyorChoiceValidation(answer2)) {
			logger.info("Enter a valid option from [1-4]");
			answer2 = sc.next();
		}
		int ans2 = Integer.parseInt(answer2);
		if (ans2 == 1)
			respondentDetails.setAnswer2(surveyDetails.getQ2Option1());
		if (ans2 == 2)
			respondentDetails.setAnswer2(surveyDetails.getQ2Option2());
		if (ans2 == 3)
			respondentDetails.setAnswer2(surveyDetails.getQ2Option3());
		if (ans2 == 4)
			respondentDetails.setAnswer2(surveyDetails.getQ2Option4());
		logger.info("3. " + surveyDetails.getQuestion3());
		logger.info("Enter your Rating from[1-5]");
		String answer3 = sc.next();
		while (!service.rateValidation(answer3)) {
			logger.info("Enter a valid Rating between 1-5");
			answer3 = sc.next();
			respondentDetails.setAnswer3(answer3);
		}
		logger.info("4. " + surveyDetails.getQuestion4());
		logger.info("Enter your answer in a single line: Accepts only[a-z][A-Z][0-9]space[.]min: 1 and max: 100");
		String answer4 = sc.next();
		while (!service.answerValidation(answer4)) {
			logger.info("Enter a valid Answer: Accepts only[a-z][A-Z][0-9]space[.]min: 1 and max: 100");
			answer4 = sc.next();
			respondentDetails.setAnswer4(answer4);
		}
		logger.info("5. " + surveyDetails.getQuestion5());
		sc.nextLine();
		logger.info(
				"Enter your answer in the form of descriptive: Accepts only[a-z][A-Z][0-9]space[.]min: 1 and max: 100");
		String answer5 = sc.nextLine();
		while (!service.answerValidation(answer5)) {
			logger.info("Enter a valid Descriptive: Accepts only[a-z][A-Z][0-9]space[.]min: 1 and max: 100");
			answer5 = sc.nextLine();
			respondentDetails.setAnswer5(answer5);
		}
		logger.info("Responses added Successfully");

		try {
			SurveyDetails responseView = service.viewSurveyService(surveyId);
			logger.info(responseView);

		} catch (SurveyNotFoundException e) {
			logger.error(e.exceptionMessage());
		}

	}

	/**
	 * To view the response we use this method.
	 * 
	 * @return
	 */
	public static List<RespondentDetails> viewResponse() {
		Service service = Factory.getServiceInstance();
		logger.info("please enter respondentId to view: which must be between [0-9] and min 1 and max 10");
		sc.nextLine();
		String respondentId = sc.nextLine();
		while (!service.idValidation(respondentId)) {
			logger.info("enter valid respondentId: which must be between [0-9] and min 1 and max 10");
			respondentId = sc.nextLine();
		}
		RespondentDetails respondentDetails = Factory.getServiceInstance().viewResponseService(respondentId);
		try {
			if (respondentDetails != null)
				logger.info(respondentDetails);
			else {
				throw new RespondentIdNotFoundException();
			}
		} catch (RespondentIdNotFoundException e) {
			logger.error(e.exceptionMessage());
		}
		return respondentDetailsList;
	}

	/**
	 * To view all the responded surveyes we use this method.
	 * 
	 * @return
	 */
	public static List<RespondentDetails> viewAllRespondedSurveyes() {
		logger.info("view all Responded Surveyes");
		logger.info(service.viewListOfRespondedSurveysService(respondentDetails));
		return respondentDetailsList;

	}

}
