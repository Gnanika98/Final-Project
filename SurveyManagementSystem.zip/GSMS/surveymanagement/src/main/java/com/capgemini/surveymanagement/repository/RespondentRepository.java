package com.capgemini.surveymanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagement.bean.RespondentBean;
import com.capgemini.surveymanagement.factory.Factory;

public class RespondentRepository {
	public static List<RespondentBean> respondentRepList = new ArrayList<>();

	public List<RespondentBean> defaultRespondentLogin() {
		RespondentBean respondent = Factory.getRespondentBeanInstance();
		respondent.setRespondentUsername("Respondent");
		respondent.setRespondentPassword("Respondent@1");
		respondent.setRespondentMailId("Respondent1@gmail.com");
		respondent.setRespondentContactNumber("7896541238");

		respondentRepList.add(respondent);
		return respondentRepList;
	}
}
