package com.capgemini.surveymanagement.dao;

import java.util.List;

import com.capgemini.surveymanagement.bean.RespondentBean;
import com.capgemini.surveymanagement.bean.RespondentDetails;
import com.capgemini.surveymanagement.bean.SurveyDetails;
import com.capgemini.surveymanagement.bean.SurveyorBean;

public interface Dao {

	public boolean adminLogin(String adminUsername, String adminPassword);

	public boolean addSurveyor(SurveyorBean surveyor);

	public boolean surveyorLogin(String surveyorUsername, String surveyorPassword);

	public boolean createSurvey(SurveyDetails surveydetails);

	public boolean updateSurvey(String surveyId);

	public boolean deleteSurvey(String surveyTitle);

	public boolean addRespondent(RespondentBean respondent);

	public boolean respondentLogin(String respondentUsername, String respondentPassword);

	public SurveyDetails viewSurvey(String surveyTitle);

	public SurveyDetails getSurvey(String surveyId);

	public SurveyDetails respondToSurvey(SurveyDetails surveyDetails);

	public RespondentDetails viewResponse(String respondentId);

	public List<RespondentDetails> viewListOfRespondedSurveys(RespondentDetails respondentdetails);

	public List<SurveyorBean> viewAllSurveyors(SurveyorBean surveyor);

	public List<RespondentBean> viewAllRespondents(RespondentBean respondent);

	public List<SurveyDetails> viewAllSurveys(SurveyDetails surveyDetails);

}
