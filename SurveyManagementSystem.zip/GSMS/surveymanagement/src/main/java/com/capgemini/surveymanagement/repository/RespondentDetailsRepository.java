package com.capgemini.surveymanagement.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveymanagement.bean.RespondentDetails;
import com.capgemini.surveymanagement.factory.Factory;

public class RespondentDetailsRepository {
	public static List<RespondentDetails> respondentDetailsRepList = new ArrayList<>();

	public List<RespondentDetails> defaultRespondentResponse() {
		RespondentDetails respondentDetails = Factory.getRespondentDetailsInstance();
		respondentDetails.setRespondentId("1");
		respondentDetails.setSurveyId("1");
		respondentDetails.setAnswer1("Excellent");
		respondentDetails.setAnswer2("Yes");
		respondentDetails.setAnswer3("3.5");
		respondentDetails.setAnswer4("At present everything is fine with the Application ");
		respondentDetails.setAnswer5(
				"The Experience with this application is really great but if some more Examples are given then it will more better");

		respondentDetailsRepList.add(respondentDetails);

		RespondentDetails respondentDetails1 = Factory.getRespondentDetailsInstance();
		respondentDetails1.setRespondentId("2");
		respondentDetails1.setSurveyId("2");
		respondentDetails1.setAnswer1("Very Good");
		respondentDetails1.setAnswer2("Good");
		respondentDetails1.setAnswer3("3.0");
		respondentDetails1.setAnswer4("Sometimes the products are not raeching our expectations");
		respondentDetails1
				.setAnswer5("OLX is really Good it made buying and selling easy and evrything is on single click");
		respondentDetailsRepList.add(respondentDetails1);
		return respondentDetailsRepList;
	}

}
